"use client"

import { useEffect, useState } from "react"

interface RealisticWelcomeAnimationProps {
  onComplete: () => void
}

export function RealisticWelcomeAnimation({ onComplete }: RealisticWelcomeAnimationProps) {
  const [isVisible, setIsVisible] = useState(true)
  const [showTruck, setShowTruck] = useState(false)
  const [fadeOut, setFadeOut] = useState(false)

  useEffect(() => {
    // Step 1: Show text immediately

    // Step 2: Start truck animation after 1 second
    const truckTimer = setTimeout(() => {
      setShowTruck(true)
    }, 1000)

    // Step 3: Start fade out after truck animation (2 seconds) + 1 second initial delay
    const fadeTimer = setTimeout(() => {
      setFadeOut(true)
    }, 3000)

    // Step 4: Complete animation and show main page
    const completeTimer = setTimeout(() => {
      setIsVisible(false)
      setTimeout(onComplete, 500) // Allow fade out to complete
    }, 3500)

    return () => {
      clearTimeout(truckTimer)
      clearTimeout(fadeTimer)
      clearTimeout(completeTimer)
    }
  }, [onComplete])

  if (!isVisible) {
    return null
  }

  return (
    <div
      className={`fixed inset-0 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-700 z-50 overflow-hidden ${fadeOut ? "animate-fade-out-slow" : ""}`}
    >
      {/* Sky and Environment */}
      <div className="absolute inset-0">
        {/* Clouds */}
        <div className="absolute top-10 left-10 w-32 h-16 bg-slate-600 rounded-full opacity-30 animate-cloud-drift-1"></div>
        <div className="absolute top-20 right-20 w-40 h-20 bg-slate-600 rounded-full opacity-20 animate-cloud-drift-2"></div>
        <div className="absolute top-16 left-1/3 w-24 h-12 bg-slate-600 rounded-full opacity-25 animate-cloud-drift-3"></div>

        {/* Sun rays */}
        <div className="absolute top-8 right-8 w-2 h-20 bg-gradient-to-b from-yellow-300 to-transparent opacity-40 rotate-12 animate-sun-ray-1"></div>
        <div className="absolute top-12 right-12 w-1 h-16 bg-gradient-to-b from-yellow-300 to-transparent opacity-30 rotate-45 animate-sun-ray-2"></div>
        <div className="absolute top-6 right-16 w-1 h-12 bg-gradient-to-b from-yellow-300 to-transparent opacity-35 rotate-75 animate-sun-ray-3"></div>
      </div>

      {/* Road with perspective */}
      <div className="absolute bottom-0 left-0 right-0 h-64 perspective-road">
        <div className="road-surface"></div>
        <div className="road-markings"></div>
        <div className="road-shoulder-left"></div>
        <div className="road-shoulder-right"></div>
      </div>

      {/* Realistic Truck */}
      {showTruck && (
        <div className="absolute bottom-20 animate-truck-realistic-drive truck-bounce">
          <div className="truck-container">
            {/* Truck Shadow */}
            <div className="truck-shadow"></div>

            {/* Main Truck Body */}
            <div className="truck-main">
              {/* Cab */}
              <div className="truck-cab">
                {/* Cab body */}
                <div className="cab-body"></div>
                {/* Windshield */}
                <div className="windshield"></div>
                <div className="windshield-frame"></div>
                {/* Side windows */}
                <div className="side-window-left"></div>
                <div className="side-window-right"></div>
                {/* Headlights */}
                <div className="headlight-left"></div>
                <div className="headlight-right"></div>
                {/* Grille */}
                <div className="grille"></div>
                {/* Bumper */}
                <div className="bumper"></div>
                {/* Exhaust pipe */}
                <div className="exhaust-pipe"></div>
                {/* Exhaust smoke */}
                <div className="exhaust-smoke"></div>
              </div>

              {/* Trailer */}
              <div className="truck-trailer">
                <div className="trailer-body"></div>
                <div className="trailer-door"></div>
                <div className="trailer-side-panel"></div>
                {/* Trailer lights */}
                <div className="trailer-light-1"></div>
                <div className="trailer-light-2"></div>
              </div>

              {/* Wheels */}
              <div className="wheel wheel-front">
                <div className="wheel-rim"></div>
                <div className="wheel-tire"></div>
                <div className="wheel-center"></div>
              </div>
              <div className="wheel wheel-cab-rear">
                <div className="wheel-rim"></div>
                <div className="wheel-tire"></div>
                <div className="wheel-center"></div>
              </div>
              <div className="wheel wheel-trailer-front">
                <div className="wheel-rim"></div>
                <div className="wheel-tire"></div>
                <div className="wheel-center"></div>
              </div>
              <div className="wheel wheel-trailer-rear">
                <div className="wheel-rim"></div>
                <div className="wheel-tire"></div>
                <div className="wheel-center"></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Welcome Text with Cinematic Effect */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="text-center">
          <h1 className="text-6xl md:text-8xl font-bold text-white mb-6">LogiMatch</h1>
          <p className="text-2xl md:text-3xl text-slate-300">Connecting Transporters & Clients</p>
          <div className="mt-8">
            <div className="flex justify-center space-x-3">
              <div className="loading-dot"></div>
              <div className="loading-dot"></div>
              <div className="loading-dot"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Lens flare effect */}
      <div className="lens-flare"></div>
    </div>
  )
}
