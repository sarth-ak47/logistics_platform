"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Users, Package, Truck, MapPin, FileText, Settings, LogOut } from "lucide-react"

interface ClientSidebarProps {
  activeItem: string
  onNavigate: (item: string) => void
  onLogout: () => void
}

export function ClientSidebar({ activeItem, onNavigate, onLogout }: ClientSidebarProps) {
  const menuItems = [
    { id: "overview", label: "Overview", icon: <FileText className="h-5 w-5" /> },
    { id: "demands", label: "My Demands", icon: <Package className="h-5 w-5" /> },
    { id: "transporters", label: "Transporters", icon: <Truck className="h-5 w-5" /> },
    { id: "matches", label: "Matches", icon: <MapPin className="h-5 w-5" /> },
    { id: "settings", label: "Settings", icon: <Settings className="h-5 w-5" /> },
  ]

  return (
    <div className="w-64 bg-slate-800 border-r border-slate-700 flex flex-col h-full">
      <div className="p-4 border-b border-slate-700">
        <Link href="/dashboard/client" className="flex items-center">
          <div className="w-10 h-10 rounded-md bg-blue-600 flex items-center justify-center text-white mr-3">
            <Users className="h-6 w-6" />
          </div>
          <span className="text-xl font-bold text-white">LogiMatch</span>
        </Link>
      </div>

      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => (
            <li key={item.id}>
              <Button
                variant="ghost"
                className={`w-full justify-start ${
                  activeItem === item.id
                    ? "bg-slate-700 text-white"
                    : "text-slate-400 hover:text-white hover:bg-slate-700"
                }`}
                onClick={() => onNavigate(item.id)}
              >
                {item.icon}
                <span className="ml-3">{item.label}</span>
              </Button>
            </li>
          ))}
        </ul>
      </nav>

      <div className="p-4 border-t border-slate-700">
        <Button
          variant="ghost"
          className="w-full justify-start text-slate-400 hover:text-white hover:bg-slate-700"
          onClick={onLogout}
        >
          <LogOut className="h-5 w-5" />
          <span className="ml-3">Logout</span>
        </Button>
      </div>
    </div>
  )
}
