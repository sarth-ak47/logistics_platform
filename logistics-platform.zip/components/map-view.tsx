"use client"

import { useEffect, useRef, useState } from "react"

interface Vehicle {
  id: string
  name: string
  status?: string
  location: {
    lat: number
    lng: number
  }
}

interface MapViewProps {
  vehicles: Vehicle[]
}

export function MapView({ vehicles }: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate map loading
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="relative w-full h-full rounded-md overflow-hidden">
      {isLoading ? (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-700">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-white"></div>
        </div>
      ) : (
        <>
          {/* This is a placeholder for a real map implementation */}
          <div
            ref={mapRef}
            className="w-full h-full bg-slate-700 relative"
            style={{
              backgroundImage: "url('/placeholder.svg?height=400&width=800')",
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          >
            {/* Vehicle markers */}
            {vehicles.map((vehicle, index) => {
              // Calculate position based on lat/lng
              // This is just a placeholder calculation
              const left = ((vehicle.location.lng - 77.5) / 1) * 100
              const top = ((12.9 - vehicle.location.lat) / 0.5) * 100

              return (
                <div
                  key={vehicle.id}
                  className={`absolute w-6 h-6 rounded-full flex items-center justify-center transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-300 hover:scale-125 ${
                    vehicle.status === "active" || vehicle.status === "available"
                      ? "bg-emerald-500"
                      : vehicle.status === "in-transit"
                        ? "bg-blue-500"
                        : "bg-amber-500"
                  }`}
                  style={{
                    left: `${Math.min(Math.max(left, 10), 90)}%`,
                    top: `${Math.min(Math.max(top, 10), 90)}%`,
                  }}
                  title={vehicle.name}
                >
                  <span className="text-xs font-bold text-white">{index + 1}</span>
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-slate-800 text-white text-xs rounded px-2 py-1 whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none">
                    {vehicle.name}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Legend */}
          <div className="absolute bottom-4 right-4 bg-slate-800 bg-opacity-80 p-2 rounded-md text-xs text-white">
            <div className="flex items-center mb-1">
              <div className="w-3 h-3 rounded-full bg-emerald-500 mr-2"></div>
              <span>Active/Available</span>
            </div>
            <div className="flex items-center mb-1">
              <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
              <span>In Transit</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-amber-500 mr-2"></div>
              <span>Maintenance</span>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
