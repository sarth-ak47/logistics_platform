"use client"

import { useEffect, useState, useRef } from "react"
import { Canvas, useFrame, useLoader } from "@react-three/fiber"
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader"
import { Environment, PerspectiveCamera } from "@react-three/drei"
import type { Group } from "three"
import { useSpring, animated } from "@react-spring/three"

interface WelcomeAnimationProps {
  onComplete: () => void
}

function Truck() {
  const gltf = useLoader(GLTFLoader, "/assets/3d/duck.glb") // Using duck as placeholder
  const truckRef = useRef<Group>(null)

  // Animation for truck movement
  const { position } = useSpring({
    from: { position: [-10, -0.5, 0] },
    to: { position: [10, -0.5, 0] },
    config: { duration: 2500 },
  })

  // Rotate wheels
  useFrame((state) => {
    if (truckRef.current) {
      // Slightly rotate the truck for better viewing angle
      truckRef.current.rotation.y = Math.PI / 4
    }
  })

  return (
    <animated.group ref={truckRef} position={position as any} scale={[2, 2, 2]}>
      <primitive object={gltf.scene} />
    </animated.group>
  )
}

function Road() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1, 0]}>
      <planeGeometry args={[30, 10]} />
      <meshStandardMaterial color="#333333" />
      {/* Road markings */}
      <mesh position={[0, 0, 0.01]}>
        <planeGeometry args={[30, 0.2]} />
        <meshStandardMaterial color="#FFFFFF" />
      </mesh>
    </mesh>
  )
}

function LogoText() {
  const textRef = useRef<Group>(null)

  const { opacity, scale } = useSpring({
    from: { opacity: 0, scale: 0.8 },
    to: { opacity: 1, scale: 1 },
    config: { duration: 1000 },
    delay: 500,
  })

  return (
    <animated.group ref={textRef} position={[0, 1.5, 0]} scale={scale as any}>
      <mesh>
        <textGeometry args={["LogiMatch", { size: 1, height: 0.2 }]} />
        <animated.meshStandardMaterial color="#FFFFFF" transparent opacity={opacity} />
      </mesh>
    </animated.group>
  )
}

function AnimationScene({ onComplete }: { onComplete: () => void }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete()
    }, 3000) // 3 seconds total animation time

    return () => clearTimeout(timer)
  }, [onComplete])

  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 2, 5]} />
      <ambientLight intensity={0.5} />
      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
      <Truck />
      <Road />
      <Environment preset="city" />
    </>
  )
}

export function WelcomeAnimation({ onComplete }: WelcomeAnimationProps) {
  const [isVisible, setIsVisible] = useState(true)

  const handleComplete = () => {
    setIsVisible(false)
    setTimeout(onComplete, 500) // Allow fade out to complete
  }

  if (!isVisible) {
    return null
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-900">
      <div className="absolute inset-0 z-10">
        <Canvas shadows>
          <AnimationScene onComplete={handleComplete} />
        </Canvas>
      </div>

      {/* Logo overlay */}
      <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
        <div className="text-center animate-fade-in-up">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-4">LogiMatch</h1>
          <p className="text-xl md:text-2xl text-slate-300">Connecting Logistics</p>
        </div>
      </div>
    </div>
  )
}
