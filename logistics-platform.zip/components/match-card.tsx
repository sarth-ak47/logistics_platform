"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, MapPin, Package, TrendingUp } from "lucide-react"

interface Match {
  id: string
  clientName: string
  material: string
  quantity: string
  location: string
  distance: string
  rate: string
  status: string
  createdAt: string
}

interface MatchCardProps {
  match: Match
  onAccept?: () => void
  onReject?: () => void
  expanded?: boolean
  showActions?: boolean
}

export function MatchCard({ match, onAccept, onReject, expanded = false, showActions = true }: MatchCardProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString()
  }

  return (
    <div className="bg-slate-700 rounded-lg p-4">
      <div className="flex justify-between items-start">
        <h3 className="font-medium text-white">{match.clientName}</h3>
        <Badge
          className={
            match.status === "pending"
              ? "bg-amber-900/30 text-amber-400 border-amber-800"
              : "bg-emerald-900/30 text-emerald-400 border-emerald-800"
          }
        >
          {match.status === "pending" ? "Pending" : "Accepted"}
        </Badge>
      </div>

      <div className="mt-2 space-y-2">
        <div className="flex items-center text-sm text-slate-300">
          <Package className="h-4 w-4 mr-2 text-slate-400" />
          <span>
            {match.material} - {match.quantity}
          </span>
        </div>

        {expanded && (
          <div className="flex items-center text-sm text-slate-300">
            <MapPin className="h-4 w-4 mr-2 text-slate-400" />
            <span>{match.location}</span>
          </div>
        )}

        <div className="flex items-center text-sm text-slate-300">
          <TrendingUp className="h-4 w-4 mr-2 text-slate-400" />
          <span>{match.rate}</span>
        </div>

        {expanded && (
          <div className="flex items-center text-sm text-slate-300">
            <Clock className="h-4 w-4 mr-2 text-slate-400" />
            <span>Created on {formatDate(match.createdAt)}</span>
          </div>
        )}
      </div>

      {showActions && match.status === "pending" && (
        <div className="flex justify-end mt-3 space-x-2">
          {onReject && (
            <Button
              variant="outline"
              size="sm"
              className="text-xs h-7 border-slate-600 text-slate-300 hover:text-white hover:bg-slate-600"
              onClick={onReject}
            >
              Reject
            </Button>
          )}
          {onAccept && (
            <Button size="sm" className="text-xs h-7 bg-emerald-600 hover:bg-emerald-700 text-white" onClick={onAccept}>
              Accept
            </Button>
          )}
        </div>
      )}
    </div>
  )
}
