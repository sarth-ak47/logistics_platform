"use client"

import { useEffect, useState, useRef, Suspense } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Environment, PerspectiveCamera, useGLTF } from "@react-three/drei"
import { useSpring, animated } from "@react-spring/three"
import * as THREE from "three"

interface TruckAnimationProps {
  onComplete: () => void
}

function Truck() {
  // Using a simple truck model
  const { scene } = useGLTF("/assets/3d/duck.glb") // Using duck as placeholder
  const truckRef = useRef<THREE.Group>(null)

  // Animation for truck movement
  const { position } = useSpring({
    from: { position: [-15, 0, 0] },
    to: { position: [15, 0, 0] },
    config: { duration: 2500 },
  })

  useFrame(() => {
    if (truckRef.current) {
      // Add slight bobbing motion to simulate driving on a road
      truckRef.current.rotation.y = Math.PI / 4
      truckRef.current.position.y = Math.sin(Date.now() * 0.003) * 0.05 - 0.5
    }
  })

  return (
    <animated.group ref={truckRef} position={position as any} scale={[2, 2, 2]}>
      <primitive object={scene} />
    </animated.group>
  )
}

function Road() {
  const roadRef = useRef<THREE.Mesh>(null)

  useFrame(() => {
    if (roadRef.current) {
      // Animate road texture to create movement illusion
      if (roadRef.current.material instanceof THREE.Material) {
        if ("map" in roadRef.current.material && roadRef.current.material.map) {
          roadRef.current.material.map.offset.x -= 0.01
        }
      }
    }
  })

  return (
    <mesh ref={roadRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, -1, 0]}>
      <planeGeometry args={[50, 10]} />
      <meshStandardMaterial color="#333333" />
      {/* Road markings */}
      <mesh position={[0, 0, 0.01]}>
        <planeGeometry args={[50, 0.2]} />
        <meshStandardMaterial color="#FFFFFF" />
      </mesh>
    </mesh>
  )
}

export function RealisticTruckAnimation({ onComplete }: TruckAnimationProps) {
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false)
      setTimeout(onComplete, 500)
    }, 2500)

    return () => clearTimeout(timer)
  }, [onComplete])

  if (!isVisible) {
    return null
  }

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-b from-slate-900 to-slate-800">
      <div className="absolute inset-0">
        <Canvas shadows>
          <PerspectiveCamera makeDefault position={[0, 2, 8]} />
          <ambientLight intensity={0.5} />
          <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
          <Suspense fallback={null}>
            <Truck />
            <Road />
            <Environment preset="city" />
          </Suspense>
        </Canvas>
      </div>

      {/* Logo overlay */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 animate-fade-in-up">LogiMatch</h1>
          <p className="text-xl md:text-2xl text-slate-300 animate-fade-in-up delay-300">
            Connecting Transporters & Clients
          </p>
          <div className="mt-8 flex justify-center space-x-2 animate-fade-in delay-500">
            <div className="w-3 h-3 bg-emerald-500 rounded-full animate-bounce"></div>
            <div className="w-3 h-3 bg-emerald-500 rounded-full animate-bounce delay-100"></div>
            <div className="w-3 h-3 bg-emerald-500 rounded-full animate-bounce delay-200"></div>
          </div>
        </div>
      </div>
    </div>
  )
}
