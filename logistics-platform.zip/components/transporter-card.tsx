"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, Package, TrendingUp } from "lucide-react"

interface Transporter {
  id: string
  name: string
  material: string
  quantity: string
  rate: string
  distance: string
  rating: number
  image: string
  status: string
}

interface TransporterCardProps {
  transporter: Transporter
  onContact: () => void
  onBook: () => void
}

export function TransporterCard({ transporter, onContact, onBook }: TransporterCardProps) {
  return (
    <Card className="bg-slate-800 border-slate-700 text-white overflow-hidden">
      <div className="flex flex-col md:flex-row">
        <div className="md:w-1/4 p-4 flex items-center justify-center">
          <div className="relative">
            <img
              src={transporter.image || "/placeholder.svg"}
              alt={transporter.name}
              className="w-24 h-24 rounded-full object-cover border-2 border-slate-700"
            />
            <Badge
              className={
                transporter.status === "available"
                  ? "absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-emerald-900/30 text-emerald-400 border-emerald-800"
                  : "absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-blue-900/30 text-blue-400 border-blue-800"
              }
            >
              {transporter.status === "available" ? "Available" : "In Transit"}
            </Badge>
          </div>
        </div>
        <div className="md:w-3/4 p-4">
          <div className="flex justify-between items-start">
            <h3 className="text-xl font-bold">{transporter.name}</h3>
            <div className="flex items-center">
              <Star className="h-4 w-4 text-yellow-400 mr-1" />
              <span>{transporter.rating.toFixed(1)}</span>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3">
            <div className="flex items-center text-sm">
              <Package className="h-4 w-4 mr-2 text-slate-400" />
              <span>{transporter.material}</span>
            </div>
            <div className="flex items-center text-sm">
              <TrendingUp className="h-4 w-4 mr-2 text-slate-400" />
              <span>{transporter.rate}</span>
            </div>
            <div className="flex items-center text-sm">
              <span className="text-slate-400 mr-2">Quantity:</span>
              <span>{transporter.quantity}</span>
            </div>
            <div className="flex items-center text-sm">
              <MapPin className="h-4 w-4 mr-2 text-slate-400" />
              <span>{transporter.distance} away</span>
            </div>
          </div>

          <div className="flex justify-end mt-4 space-x-2">
            <Button variant="outline" size="sm" className="border-slate-600" onClick={onContact}>
              Contact
            </Button>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700" onClick={onBook}>
              Book Now
            </Button>
          </div>
        </div>
      </div>
    </Card>
  )
}
