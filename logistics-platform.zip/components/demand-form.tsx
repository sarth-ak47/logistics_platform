"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface DemandFormProps {
  onSubmit: (data: any) => void
  onCancel: () => void
}

export function DemandForm({ onSubmit, onCancel }: DemandFormProps) {
  const [formData, setFormData] = useState({
    material: "",
    quantity: "",
    rate: "",
    location: "",
    urgency: "normal",
    notes: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  return (
    <Card className="bg-slate-800 border-slate-700 text-white">
      <CardHeader>
        <CardTitle>Add New Demand</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="material">Material Required</Label>
              <Input
                id="material"
                name="material"
                value={formData.material}
                onChange={handleChange}
                placeholder="e.g. Sand, Gravel, Cement"
                required
                className="bg-slate-700 border-slate-600"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity Needed</Label>
              <Input
                id="quantity"
                name="quantity"
                value={formData.quantity}
                onChange={handleChange}
                placeholder="e.g. 20 tons"
                required
                className="bg-slate-700 border-slate-600"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rate">Desired Rate</Label>
              <Input
                id="rate"
                name="rate"
                value={formData.rate}
                onChange={handleChange}
                placeholder="e.g. ₹1200 per ton"
                required
                className="bg-slate-700 border-slate-600"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Delivery Location</Label>
              <Input
                id="location"
                name="location"
                value={formData.location}
                onChange={handleChange}
                placeholder="e.g. Whitefield, Bangalore"
                required
                className="bg-slate-700 border-slate-600"
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="urgency">Urgency Level</Label>
              <Select value={formData.urgency} onValueChange={(value) => handleSelectChange("urgency", value)}>
                <SelectTrigger className="bg-slate-700 border-slate-600">
                  <SelectValue placeholder="Select urgency level" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  <SelectItem value="low" className="text-white hover:bg-slate-600">
                    Low - Within a month
                  </SelectItem>
                  <SelectItem value="normal" className="text-white hover:bg-slate-600">
                    Normal - Within a week
                  </SelectItem>
                  <SelectItem value="high" className="text-white hover:bg-slate-600">
                    High - Within 48 hours
                  </SelectItem>
                  <SelectItem value="urgent" className="text-white hover:bg-slate-600">
                    Urgent - Within 24 hours
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Additional Notes (Optional)</Label>
            <Textarea
              id="notes"
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              placeholder="Enter any additional requirements or notes..."
              className="bg-slate-700 border-slate-600 min-h-[100px]"
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button type="button" variant="outline" onClick={onCancel} className="border-slate-600">
            Cancel
          </Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
            Add Demand
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
