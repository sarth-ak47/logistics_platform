"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Bell, Truck, MapPin, Package, Plus } from "lucide-react"
import { TransporterSidebar } from "@/components/transporter-sidebar"
import { VehicleForm } from "@/components/vehicle-form"
import { MaterialForm } from "@/components/material-form"
import { TruckModel } from "@/components/truck-model"
import { MapView } from "@/components/map-view"
import { MatchCard } from "@/components/match-card"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { getTransporterData } from "@/lib/data-actions"

export default function TransporterDashboard() {
  const { toast } = useToast()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("overview")
  const [showVehicleForm, setShowVehicleForm] = useState(false)
  const [showMaterialForm, setShowMaterialForm] = useState(false)
  const [userData, setUserData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getTransporterData()
        setUserData(data)
      } catch (error) {
        console.error("Failed to fetch data:", error)
        toast({
          title: "Error",
          description: "Failed to load your data. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [toast])

  // Mock data for demonstration
  const vehicles = userData?.vehicles || [
    {
      id: "v1",
      name: "Volvo FH16",
      number: "KA-01-AB-1234",
      driverName: "John Doe",
      ownerName: "Logistics Co Ltd",
      contactNumber: "+91 9876543210",
      driverNumber: "+91 9876543211",
      image: "/placeholder.svg?height=200&width=300",
      status: "active",
      location: { lat: 12.9716, lng: 77.5946 },
    },
    {
      id: "v2",
      name: "Tata Prima",
      number: "KA-02-CD-5678",
      driverName: "Jane Smith",
      ownerName: "Logistics Co Ltd",
      contactNumber: "+91 9876543212",
      driverNumber: "+91 9876543213",
      image: "/placeholder.svg?height=200&width=300",
      status: "maintenance",
      location: { lat: 13.0827, lng: 80.2707 },
    },
  ]

  const materials = userData?.materials || [
    {
      id: "m1",
      name: "Sand",
      quantity: "20 tons",
      quality: "Fine",
      loadingStation: "Bangalore South",
      sellingRate: "₹1200 per ton",
      image: "/placeholder.svg?height=150&width=150",
      status: "available",
    },
    {
      id: "m2",
      name: "Gravel",
      quantity: "15 tons",
      quality: "Medium",
      loadingStation: "Mysore Road",
      sellingRate: "₹1500 per ton",
      image: "/placeholder.svg?height=150&width=150",
      status: "in-transit",
    },
  ]

  const matches = userData?.matches || [
    {
      id: "match1",
      clientName: "BuildWell Construction",
      material: "Sand",
      quantity: "10 tons",
      location: "Whitefield, Bangalore",
      distance: "12 km",
      rate: "₹1250 per ton",
      status: "pending",
      createdAt: "2023-05-15T10:30:00Z",
    },
    {
      id: "match2",
      clientName: "Metro Developers",
      material: "Gravel",
      quantity: "8 tons",
      location: "Electronic City, Bangalore",
      distance: "18 km",
      rate: "₹1550 per ton",
      status: "accepted",
      createdAt: "2023-05-14T14:45:00Z",
    },
  ]

  const handleLogout = () => {
    // Implement logout logic here
    router.push("/login")
  }

  const playMatchSound = () => {
    const audio = new Audio("/truck-horn.mp3")
    audio.play()
  }

  return (
    <div className="flex h-screen bg-slate-900">
      <TransporterSidebar activeItem={activeTab} onNavigate={setActiveTab} onLogout={handleLogout} />

      <div className="flex-1 overflow-auto">
        <header className="bg-slate-800 border-b border-slate-700 p-4 sticky top-0 z-10">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-bold text-white">Transporter Dashboard</h1>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="icon" className="relative text-slate-300 border-slate-700">
                <Bell className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  3
                </span>
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center text-white font-semibold">
                  {userData?.name?.charAt(0) || "T"}
                </div>
                <span className="text-white">{userData?.name || "Transporter"}</span>
              </div>
            </div>
          </div>
        </header>

        <main className="p-6">
          <div className={activeTab === "overview" ? "block" : "hidden"}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card className="bg-slate-800 border-slate-700 text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Active Vehicles</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-end justify-between">
                    <div className="text-3xl font-bold">{vehicles.filter((v) => v.status === "active").length}</div>
                    <Truck className="h-8 w-8 text-emerald-500" />
                  </div>
                  <p className="text-sm text-slate-400 mt-2">
                    {vehicles.filter((v) => v.status === "active").length} of {vehicles.length} vehicles currently
                    active
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700 text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Available Materials</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-end justify-between">
                    <div className="text-3xl font-bold">{materials.filter((m) => m.status === "available").length}</div>
                    <Package className="h-8 w-8 text-blue-500" />
                  </div>
                  <p className="text-sm text-slate-400 mt-2">
                    {materials.filter((m) => m.status === "available").length} materials ready for transport
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700 text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Potential Matches</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-end justify-between">
                    <div className="text-3xl font-bold">{matches.filter((m) => m.status === "pending").length}</div>
                    <MapPin className="h-8 w-8 text-red-500" />
                  </div>
                  <p className="text-sm text-slate-400 mt-2">
                    {matches.filter((m) => m.status === "pending").length} new client matches available
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card className="bg-slate-800 border-slate-700 text-white h-full">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle>Vehicle Tracking</CardTitle>
                      <Badge variant="outline" className="bg-emerald-900/30 text-emerald-400 border-emerald-800">
                        Live
                      </Badge>
                    </div>
                    <CardDescription className="text-slate-400">
                      Real-time location of your active vehicles
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[400px] relative">
                    <MapView vehicles={vehicles} />
                  </CardContent>
                </Card>
              </div>

              <div>
                <Card className="bg-slate-800 border-slate-700 text-white mb-6">
                  <CardHeader>
                    <CardTitle>Recent Matches</CardTitle>
                    <CardDescription className="text-slate-400">Client matches in the last 7 days</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {matches.slice(0, 3).map((match) => (
                        <MatchCard
                          key={match.id}
                          match={match}
                          onAccept={() => {
                            toast({
                              title: "Match Accepted",
                              description: `You've accepted the match with ${match.clientName}`,
                            })
                            playMatchSound()
                          }}
                          onReject={() => {
                            toast({
                              title: "Match Rejected",
                              description: `You've rejected the match with ${match.clientName}`,
                              variant: "destructive",
                            })
                          }}
                        />
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-800 border-slate-700 text-white">
                  <CardHeader>
                    <CardTitle>3D Truck Viewer</CardTitle>
                    <CardDescription className="text-slate-400">Interactive 3D model of your vehicle</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[200px] flex items-center justify-center">
                    <TruckModel />
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          <div className={activeTab === "vehicles" ? "block" : "hidden"}>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">My Vehicles</h2>
              <Button
                onClick={() => setShowVehicleForm(true)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <Plus className="mr-2 h-4 w-4" /> Add Vehicle
              </Button>
            </div>

            {showVehicleForm ? (
              <VehicleForm
                onSubmit={(data) => {
                  console.log("Vehicle data:", data)
                  toast({
                    title: "Vehicle Added",
                    description: "Your vehicle has been successfully added.",
                  })
                  setShowVehicleForm(false)
                }}
                onCancel={() => setShowVehicleForm(false)}
              />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {vehicles.map((vehicle) => (
                  <Card key={vehicle.id} className="bg-slate-800 border-slate-700 text-white overflow-hidden">
                    <div className="flex flex-col md:flex-row">
                      <div className="md:w-1/3">
                        <img
                          src={vehicle.image || "/placeholder.svg"}
                          alt={vehicle.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="md:w-2/3 p-4">
                        <div className="flex justify-between items-start">
                          <h3 className="text-xl font-bold">{vehicle.name}</h3>
                          <Badge
                            className={
                              vehicle.status === "active"
                                ? "bg-emerald-900/30 text-emerald-400 border-emerald-800"
                                : "bg-amber-900/30 text-amber-400 border-amber-800"
                            }
                          >
                            {vehicle.status === "active" ? "Active" : "Maintenance"}
                          </Badge>
                        </div>
                        <p className="text-lg font-semibold mt-1">{vehicle.number}</p>
                        <div className="grid grid-cols-2 gap-2 mt-4 text-sm">
                          <div>
                            <p className="text-slate-400">Driver</p>
                            <p>{vehicle.driverName}</p>
                          </div>
                          <div>
                            <p className="text-slate-400">Owner</p>
                            <p>{vehicle.ownerName}</p>
                          </div>
                          <div>
                            <p className="text-slate-400">Contact</p>
                            <p>{vehicle.contactNumber}</p>
                          </div>
                          <div>
                            <p className="text-slate-400">Driver Contact</p>
                            <p>{vehicle.driverNumber}</p>
                          </div>
                        </div>
                        <div className="flex justify-end mt-4 space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-600"
                          >
                            Edit
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-600"
                          >
                            Track
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>

          <div className={activeTab === "materials" ? "block" : "hidden"}>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Materials</h2>
              <Button
                onClick={() => setShowMaterialForm(true)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <Plus className="mr-2 h-4 w-4" /> Add Material
              </Button>
            </div>

            {showMaterialForm ? (
              <MaterialForm
                onSubmit={(data) => {
                  console.log("Material data:", data)
                  toast({
                    title: "Material Added",
                    description: "Your material has been successfully added.",
                  })
                  setShowMaterialForm(false)
                }}
                onCancel={() => setShowMaterialForm(false)}
              />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {materials.map((material) => (
                  <Card key={material.id} className="bg-slate-800 border-slate-700 text-white">
                    <div className="p-4 flex items-center space-x-4">
                      <div className="w-16 h-16 rounded-md overflow-hidden flex-shrink-0">
                        <img
                          src={material.image || "/placeholder.svg"}
                          alt={material.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold">{material.name}</h3>
                        <Badge
                          className={
                            material.status === "available"
                              ? "bg-emerald-900/30 text-emerald-400 border-emerald-800"
                              : "bg-blue-900/30 text-blue-400 border-blue-800"
                          }
                        >
                          {material.status === "available" ? "Available" : "In Transit"}
                        </Badge>
                      </div>
                    </div>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <p className="text-slate-400">Quantity</p>
                          <p>{material.quantity}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Quality</p>
                          <p>{material.quality}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Loading Station</p>
                          <p>{material.loadingStation}</p>
                        </div>
                        <div>
                          <p className="text-slate-400">Selling Rate</p>
                          <p>{material.sellingRate}</p>
                        </div>
                      </div>
                      <div className="flex justify-end mt-4 space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-600"
                        >
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-600"
                        >
                          View Matches
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          <div className={activeTab === "matches" ? "block" : "hidden"}>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-white">Client Matches</h2>
              <p className="text-slate-400">Potential clients that match your materials and routes</p>
            </div>

            <Tabs defaultValue="pending">
              <TabsList className="bg-slate-700">
                <TabsTrigger
                  value="pending"
                  className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-300"
                >
                  Pending
                </TabsTrigger>
                <TabsTrigger
                  value="accepted"
                  className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-300"
                >
                  Accepted
                </TabsTrigger>
                <TabsTrigger
                  value="completed"
                  className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-300"
                >
                  Completed
                </TabsTrigger>
              </TabsList>

              <div className="mt-6">
                <TabsContent value="pending">
                  <div className="space-y-4">
                    {matches
                      .filter((m) => m.status === "pending")
                      .map((match) => (
                        <MatchCard
                          key={match.id}
                          match={match}
                          onAccept={() => {
                            toast({
                              title: "Match Accepted",
                              description: `You've accepted the match with ${match.clientName}`,
                            })
                            playMatchSound()
                          }}
                          onReject={() => {
                            toast({
                              title: "Match Rejected",
                              description: `You've rejected the match with ${match.clientName}`,
                              variant: "destructive",
                            })
                          }}
                          expanded
                        />
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="accepted">
                  <div className="space-y-4">
                    {matches
                      .filter((m) => m.status === "accepted")
                      .map((match) => (
                        <MatchCard key={match.id} match={match} expanded showActions={false} />
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="completed">
                  <div className="space-y-4">
                    {/* No completed matches in our mock data */}
                    <div className="text-center py-12 text-slate-400">
                      <p>No completed matches yet</p>
                    </div>
                  </div>
                </TabsContent>
              </div>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  )
}
