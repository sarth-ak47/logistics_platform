"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Bell, Truck, MapPin, Package, Plus } from "lucide-react"
import { ClientSidebar } from "@/components/client-sidebar"
import { DemandForm } from "@/components/demand-form"
import { MapView } from "@/components/map-view"
import { TransporterCard } from "@/components/transporter-card"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { getClientData } from "@/lib/data-actions"

export default function ClientDashboard() {
  const { toast } = useToast()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("overview")
  const [showDemandForm, setShowDemandForm] = useState(false)
  const [userData, setUserData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getClientData()
        setUserData(data)
      } catch (error) {
        console.error("Failed to fetch data:", error)
        toast({
          title: "Error",
          description: "Failed to load your data. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [toast])

  // Mock data for demonstration
  const demands = userData?.demands || [
    {
      id: "d1",
      material: "Sand",
      quantity: "15 tons",
      rate: "₹1200 per ton",
      location: "Whitefield, Bangalore",
      status: "active",
      createdAt: "2023-05-15T10:30:00Z",
    },
    {
      id: "d2",
      material: "Gravel",
      quantity: "10 tons",
      rate: "₹1500 per ton",
      location: "Electronic City, Bangalore",
      status: "matched",
      createdAt: "2023-05-14T14:45:00Z",
    },
  ]

  const transporters = userData?.transporters || [
    {
      id: "t1",
      name: "SpeedyTruck Logistics",
      material: "Sand",
      quantity: "20 tons",
      rate: "₹1250 per ton",
      distance: "12 km",
      rating: 4.8,
      image: "/placeholder.svg?height=100&width=100",
      status: "available",
    },
    {
      id: "t2",
      name: "Highway Haulers",
      material: "Gravel",
      quantity: "15 tons",
      rate: "₹1550 per ton",
      distance: "18 km",
      rating: 4.5,
      image: "/placeholder.svg?height=100&width=100",
      status: "available",
    },
    {
      id: "t3",
      name: "City Carriers",
      material: "Cement",
      quantity: "25 tons",
      rate: "₹1350 per ton",
      distance: "22 km",
      rating: 4.2,
      image: "/placeholder.svg?height=100&width=100",
      status: "in-transit",
    },
  ]

  const matches = userData?.matches || [
    {
      id: "match1",
      transporterName: "SpeedyTruck Logistics",
      material: "Sand",
      quantity: "15 tons",
      location: "Whitefield, Bangalore",
      distance: "12 km",
      rate: "₹1250 per ton",
      status: "pending",
      createdAt: "2023-05-15T10:30:00Z",
    },
    {
      id: "match2",
      transporterName: "Highway Haulers",
      material: "Gravel",
      quantity: "10 tons",
      location: "Electronic City, Bangalore",
      distance: "18 km",
      rate: "₹1550 per ton",
      status: "accepted",
      createdAt: "2023-05-14T14:45:00Z",
    },
  ]

  const handleLogout = () => {
    // Implement logout logic here
    router.push("/login")
  }

  const playMatchSound = () => {
    const audio = new Audio("/truck-horn.mp3")
    audio.play()
  }

  return (
    <div className="flex h-screen bg-slate-900">
      <ClientSidebar activeItem={activeTab} onNavigate={setActiveTab} onLogout={handleLogout} />

      <div className="flex-1 overflow-auto">
        <header className="bg-slate-800 border-b border-slate-700 p-4 sticky top-0 z-10">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-bold text-white">Client Dashboard</h1>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="icon" className="relative text-slate-300 border-slate-700">
                <Bell className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  2
                </span>
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-semibold">
                  {userData?.name?.charAt(0) || "C"}
                </div>
                <span className="text-white">{userData?.name || "Client"}</span>
              </div>
            </div>
          </div>
        </header>

        <main className="p-6">
          <div className={activeTab === "overview" ? "block" : "hidden"}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card className="bg-slate-800 border-slate-700 text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Active Demands</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-end justify-between">
                    <div className="text-3xl font-bold">{demands.filter((d) => d.status === "active").length}</div>
                    <Package className="h-8 w-8 text-blue-500" />
                  </div>
                  <p className="text-sm text-slate-400 mt-2">
                    {demands.filter((d) => d.status === "active").length} of {demands.length} demands currently active
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700 text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Available Transporters</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-end justify-between">
                    <div className="text-3xl font-bold">
                      {transporters.filter((t) => t.status === "available").length}
                    </div>
                    <Truck className="h-8 w-8 text-emerald-500" />
                  </div>
                  <p className="text-sm text-slate-400 mt-2">
                    {transporters.filter((t) => t.status === "available").length} transporters available for your
                    demands
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700 text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Potential Matches</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-end justify-between">
                    <div className="text-3xl font-bold">{matches.filter((m) => m.status === "pending").length}</div>
                    <MapPin className="h-8 w-8 text-red-500" />
                  </div>
                  <p className="text-sm text-slate-400 mt-2">
                    {matches.filter((m) => m.status === "pending").length} new transporter matches available
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card className="bg-slate-800 border-slate-700 text-white h-full">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle>Transporter Locations</CardTitle>
                      <Badge variant="outline" className="bg-blue-900/30 text-blue-400 border-blue-800">
                        Near You
                      </Badge>
                    </div>
                    <CardDescription className="text-slate-400">
                      Available transporters near your locations
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[400px] relative">
                    <MapView
                      vehicles={transporters.map((t, index) => ({
                        id: t.id,
                        name: t.name,
                        status: t.status,
                        // Generate random locations around Bangalore for demo
                        location: {
                          lat: 12.9716 + (Math.random() * 0.2 - 0.1),
                          lng: 77.5946 + (Math.random() * 0.2 - 0.1),
                        },
                      }))}
                    />
                  </CardContent>
                </Card>
              </div>

              <div>
                <Card className="bg-slate-800 border-slate-700 text-white mb-6">
                  <CardHeader>
                    <CardTitle>Recent Matches</CardTitle>
                    <CardDescription className="text-slate-400">Transporter matches in the last 7 days</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {matches.slice(0, 3).map((match) => (
                        <div key={match.id} className="bg-slate-700 rounded-lg p-3">
                          <div className="flex justify-between items-start">
                            <h3 className="font-medium text-white">{match.transporterName}</h3>
                            <Badge
                              className={
                                match.status === "pending"
                                  ? "bg-amber-900/30 text-amber-400 border-amber-800"
                                  : "bg-emerald-900/30 text-emerald-400 border-emerald-800"
                              }
                            >
                              {match.status === "pending" ? "Pending" : "Accepted"}
                            </Badge>
                          </div>
                          <p className="text-sm text-slate-300 mt-1">
                            {match.material} - {match.quantity}
                          </p>
                          <div className="flex justify-between items-center mt-2 text-xs text-slate-400">
                            <span>{match.distance} away</span>
                            <span>{match.rate}</span>
                          </div>
                          {match.status === "pending" && (
                            <div className="flex justify-end mt-3 space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-xs h-7 border-slate-600"
                                onClick={() => {
                                  toast({
                                    title: "Match Rejected",
                                    description: `You've rejected the match with ${match.transporterName}`,
                                    variant: "destructive",
                                  })
                                }}
                              >
                                Reject
                              </Button>
                              <Button
                                size="sm"
                                className="text-xs h-7 bg-blue-600 hover:bg-blue-700"
                                onClick={() => {
                                  toast({
                                    title: "Match Accepted",
                                    description: `You've accepted the match with ${match.transporterName}`,
                                  })
                                  playMatchSound()
                                }}
                              >
                                Accept
                              </Button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-800 border-slate-700 text-white">
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Button
                        className="w-full bg-blue-600 hover:bg-blue-700 justify-start"
                        onClick={() => setShowDemandForm(true)}
                      >
                        <Plus className="mr-2 h-4 w-4" /> Add New Demand
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full border-slate-600 justify-start"
                        onClick={() => setActiveTab("transporters")}
                      >
                        <Truck className="mr-2 h-4 w-4" /> Browse Transporters
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full border-slate-600 justify-start"
                        onClick={() => setActiveTab("matches")}
                      >
                        <MapPin className="mr-2 h-4 w-4" /> View All Matches
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          <div className={activeTab === "demands" ? "block" : "hidden"}>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">My Demands</h2>
              <Button onClick={() => setShowDemandForm(true)} className="bg-blue-600 hover:bg-blue-700 text-white">
                <Plus className="mr-2 h-4 w-4" /> Add Demand
              </Button>
            </div>

            {showDemandForm ? (
              <DemandForm
                onSubmit={(data) => {
                  console.log("Demand data:", data)
                  toast({
                    title: "Demand Added",
                    description: "Your demand has been successfully added.",
                  })
                  setShowDemandForm(false)
                }}
                onCancel={() => setShowDemandForm(false)}
              />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {demands.map((demand) => (
                  <Card key={demand.id} className="bg-slate-800 border-slate-700 text-white">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle>{demand.material}</CardTitle>
                        <Badge
                          className={
                            demand.status === "active"
                              ? "bg-blue-900/30 text-blue-400 border-blue-800"
                              : "bg-emerald-900/30 text-emerald-400 border-emerald-800"
                          }
                        >
                          {demand.status === "active" ? "Active" : "Matched"}
                        </Badge>
                      </div>
                      <CardDescription className="text-slate-400">
                        Created on {new Date(demand.createdAt).toLocaleDateString()}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-sm text-slate-400">Quantity</p>
                          <p className="font-medium">{demand.quantity}</p>
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Rate</p>
                          <p className="font-medium">{demand.rate}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-sm text-slate-400">Location</p>
                          <p className="font-medium">{demand.location}</p>
                        </div>
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" size="sm" className="border-slate-600">
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          className="bg-blue-600 hover:bg-blue-700"
                          onClick={() => setActiveTab("transporters")}
                        >
                          Find Transporters
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          <div className={activeTab === "transporters" ? "block" : "hidden"}>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-white">Available Transporters</h2>
              <p className="text-slate-400">Transporters that match your material requirements</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {transporters.map((transporter) => (
                <TransporterCard
                  key={transporter.id}
                  transporter={transporter}
                  onContact={() => {
                    toast({
                      title: "Contact Request Sent",
                      description: `Your contact request has been sent to ${transporter.name}`,
                    })
                  }}
                  onBook={() => {
                    toast({
                      title: "Booking Request Sent",
                      description: `Your booking request has been sent to ${transporter.name}`,
                    })
                    playMatchSound()
                  }}
                />
              ))}
            </div>
          </div>

          <div className={activeTab === "matches" ? "block" : "hidden"}>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-white">Transporter Matches</h2>
              <p className="text-slate-400">Transporters that match your demands</p>
            </div>

            <Tabs defaultValue="pending">
              <TabsList className="bg-slate-700">
                <TabsTrigger
                  value="pending"
                  className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-300"
                >
                  Pending
                </TabsTrigger>
                <TabsTrigger
                  value="accepted"
                  className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-300"
                >
                  Accepted
                </TabsTrigger>
                <TabsTrigger
                  value="completed"
                  className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-300"
                >
                  Completed
                </TabsTrigger>
              </TabsList>

              <div className="mt-6">
                <TabsContent value="pending">
                  <div className="space-y-4">
                    {matches
                      .filter((m) => m.status === "pending")
                      .map((match) => (
                        <Card key={match.id} className="bg-slate-800 border-slate-700 text-white">
                          <CardHeader>
                            <div className="flex justify-between items-start">
                              <CardTitle>{match.transporterName}</CardTitle>
                              <Badge className="bg-amber-900/30 text-amber-400 border-amber-800">Pending</Badge>
                            </div>
                            <CardDescription className="text-slate-400">
                              Match created on {new Date(match.createdAt).toLocaleDateString()}
                            </CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-2 gap-4 mb-4">
                              <div>
                                <p className="text-sm text-slate-400">Material</p>
                                <p className="font-medium">{match.material}</p>
                              </div>
                              <div>
                                <p className="text-sm text-slate-400">Quantity</p>
                                <p className="font-medium">{match.quantity}</p>
                              </div>
                              <div>
                                <p className="text-sm text-slate-400">Rate</p>
                                <p className="font-medium">{match.rate}</p>
                              </div>
                              <div>
                                <p className="text-sm text-slate-400">Distance</p>
                                <p className="font-medium">{match.distance}</p>
                              </div>
                              <div className="col-span-2">
                                <p className="text-sm text-slate-400">Location</p>
                                <p className="font-medium">{match.location}</p>
                              </div>
                            </div>
                            <div className="flex justify-end space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-slate-600"
                                onClick={() => {
                                  toast({
                                    title: "Match Rejected",
                                    description: `You've rejected the match with ${match.transporterName}`,
                                    variant: "destructive",
                                  })
                                }}
                              >
                                Reject
                              </Button>
                              <Button
                                size="sm"
                                className="bg-blue-600 hover:bg-blue-700"
                                onClick={() => {
                                  toast({
                                    title: "Match Accepted",
                                    description: `You've accepted the match with ${match.transporterName}`,
                                  })
                                  playMatchSound()
                                }}
                              >
                                Accept
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="accepted">
                  <div className="space-y-4">
                    {matches
                      .filter((m) => m.status === "accepted")
                      .map((match) => (
                        <Card key={match.id} className="bg-slate-800 border-slate-700 text-white">
                          <CardHeader>
                            <div className="flex justify-between items-start">
                              <CardTitle>{match.transporterName}</CardTitle>
                              <Badge className="bg-emerald-900/30 text-emerald-400 border-emerald-800">Accepted</Badge>
                            </div>
                            <CardDescription className="text-slate-400">
                              Match created on {new Date(match.createdAt).toLocaleDateString()}
                            </CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-2 gap-4 mb-4">
                              <div>
                                <p className="text-sm text-slate-400">Material</p>
                                <p className="font-medium">{match.material}</p>
                              </div>
                              <div>
                                <p className="text-sm text-slate-400">Quantity</p>
                                <p className="font-medium">{match.quantity}</p>
                              </div>
                              <div>
                                <p className="text-sm text-slate-400">Rate</p>
                                <p className="font-medium">{match.rate}</p>
                              </div>
                              <div>
                                <p className="text-sm text-slate-400">Distance</p>
                                <p className="font-medium">{match.distance}</p>
                              </div>
                              <div className="col-span-2">
                                <p className="text-sm text-slate-400">Location</p>
                                <p className="font-medium">{match.location}</p>
                              </div>
                            </div>
                            <div className="flex justify-end">
                              <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                                Track Delivery
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="completed">
                  <div className="space-y-4">
                    {/* No completed matches in our mock data */}
                    <div className="text-center py-12 text-slate-400">
                      <p>No completed matches yet</p>
                    </div>
                  </div>
                </TabsContent>
              </div>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  )
}
