import type React from "react"
import "@/app/globals.css"
import { ThemeProvider } from "@/components/theme-provider"

export const metadata = {
  title: "LogiMatch - Connect Transporters & Clients",
  description: "The smart logistics platform that matches transporters with clients for optimal delivery solutions.",
    generator: 'v0.dev'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* Preload 3D model for faster animation */}
        <link rel="preload" href="/assets/3d/duck.glb" as="fetch" crossOrigin="anonymous" />
      </head>
      <body>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
