"use client"

import type React from "react"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Truck, Users } from "lucide-react"
import Link from "next/link"
import { registerUser } from "@/lib/auth-actions"
import { useToast } from "@/components/ui/use-toast"

export default function RegisterPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const defaultRole = searchParams.get("role") || "transporter"
  const { toast } = useToast()

  const [role, setRole] = useState<"transporter" | "client">(defaultRole as "transporter" | "client")
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    if (password !== confirmPassword) {
      setError("Passwords do not match")
      setIsLoading(false)
      return
    }

    try {
      const result = await registerUser({ name, email, password, role })

      if (result.success) {
        toast({
          title: "Registration successful",
          description: `Welcome to LogiMatch, ${name}!`,
        })
        // Redirect to the appropriate dashboard
        router.push(role === "transporter" ? "/dashboard/transporter" : "/dashboard/client")
      } else {
        setError(result.error || "Registration failed. Please try again.")
        toast({
          title: "Registration failed",
          description: result.error || "Please check your information and try again.",
          variant: "destructive",
        })
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-slate-800 border-slate-700 text-white">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-2">
            <Link href="/" className="text-2xl font-bold text-white">
              LogiMatch
            </Link>
          </div>
          <CardTitle className="text-2xl text-center">Create an account</CardTitle>
          <CardDescription className="text-center text-slate-400">
            Enter your details to create your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleRegister}>
            <div className="space-y-4">
              <Tabs defaultValue={role} onValueChange={(value) => setRole(value as "transporter" | "client")}>
                <TabsList className="grid w-full grid-cols-2 bg-slate-700">
                  <TabsTrigger
                    value="transporter"
                    className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white text-slate-300"
                  >
                    <Truck className="mr-2 h-4 w-4" />
                    Transporter
                  </TabsTrigger>
                  <TabsTrigger
                    value="client"
                    className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-300"
                  >
                    <Users className="mr-2 h-4 w-4" />
                    Client
                  </TabsTrigger>
                </TabsList>
              </Tabs>

              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  placeholder="John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  className="bg-slate-700 border-slate-600"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600"
                />
              </div>

              {error && (
                <div className="bg-red-900/30 border border-red-800 text-red-300 p-3 rounded-md text-sm">{error}</div>
              )}
            </div>

            <Button
              type="submit"
              className="w-full mt-6"
              disabled={isLoading}
              style={{
                backgroundColor: role === "transporter" ? "rgb(5, 150, 105)" : "rgb(37, 99, 235)",
                color: "white",
              }}
            >
              {isLoading ? "Creating account..." : "Create account"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-center text-sm text-slate-400">
            Already have an account?{" "}
            <Link href="/login" className="text-white hover:underline">
              Login
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
