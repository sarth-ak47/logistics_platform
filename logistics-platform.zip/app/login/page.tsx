"use client"

import type React from "react"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Truck, Users } from "lucide-react"
import Link from "next/link"
import { loginUser } from "@/lib/auth-actions"
import { useToast } from "@/components/ui/use-toast"

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const defaultRole = searchParams.get("role") || "transporter"
  const { toast } = useToast()

  const [role, setRole] = useState<"transporter" | "client">(defaultRole as "transporter" | "client")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      const result = await loginUser({ email, password, role })

      if (result.success) {
        toast({
          title: "Login successful",
          description: `Welcome back, ${result.user.name}!`,
        })
        // Redirect to the appropriate dashboard
        router.push(role === "transporter" ? "/dashboard/transporter" : "/dashboard/client")
      } else {
        setError(result.error || "Login failed. Please check your credentials.")
        toast({
          title: "Login failed",
          description: result.error || "Please check your credentials and try again.",
          variant: "destructive",
        })
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-slate-800 border-slate-700 text-white">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-2">
            <Link href="/" className="text-2xl font-bold text-white">
              LogiMatch
            </Link>
          </div>
          <CardTitle className="text-2xl text-center">Login to your account</CardTitle>
          <CardDescription className="text-center text-slate-400">
            Enter your email and password to login
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin}>
            <div className="space-y-4">
              <Tabs defaultValue={role} onValueChange={(value) => setRole(value as "transporter" | "client")}>
                <TabsList className="grid w-full grid-cols-2 bg-slate-700">
                  <TabsTrigger
                    value="transporter"
                    className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white text-slate-300"
                  >
                    <Truck className="mr-2 h-4 w-4" />
                    Transporter
                  </TabsTrigger>
                  <TabsTrigger
                    value="client"
                    className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-300"
                  >
                    <Users className="mr-2 h-4 w-4" />
                    Client
                  </TabsTrigger>
                </TabsList>
              </Tabs>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <Link href="/forgot-password" className="text-sm text-slate-400 hover:text-white">
                    Forgot password?
                  </Link>
                </div>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600"
                />
              </div>

              {error && (
                <div className="bg-red-900/30 border border-red-800 text-red-300 p-3 rounded-md text-sm">{error}</div>
              )}
            </div>

            <Button
              type="submit"
              className="w-full mt-6"
              disabled={isLoading}
              style={{
                backgroundColor: role === "transporter" ? "rgb(5, 150, 105)" : "rgb(37, 99, 235)",
                color: "white",
              }}
            >
              {isLoading ? "Logging in..." : "Login"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-center text-sm text-slate-400">
            Don&apos;t have an account?{" "}
            <Link href="/register" className="text-white hover:underline">
              Register
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
