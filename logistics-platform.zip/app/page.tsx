"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Truck, Users, ArrowRight } from "lucide-react"
import { RealisticWelcomeAnimation } from "@/components/realistic-welcome-animation"

export default function Home() {
  const [showAnimation, setShowAnimation] = useState(true)

  if (showAnimation) {
    return <RealisticWelcomeAnimation onComplete={() => setShowAnimation(false)} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 flex flex-col animate-fade-in">
      <header className="container mx-auto py-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-white">LogiMatch</h1>
          <div className="space-x-2">
            <Link href="/login">
              <Button variant="outline" className="text-white border-white hover:bg-white hover:text-slate-900">
                Login
              </Button>
            </Link>
            <Link href="/register">
              <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">Register</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">Connect Transporters & Clients</h1>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            The smart logistics platform that matches transporters with clients for optimal delivery solutions.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <Card className="bg-slate-800 border-slate-700 text-white hover:bg-slate-700 transition-colors">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-emerald-600 flex items-center justify-center mb-4">
                <Truck className="w-6 h-6" />
              </div>
              <CardTitle className="text-2xl">For Transporters</CardTitle>
              <CardDescription className="text-slate-300">
                Register your vehicles and find clients looking for transportation services.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <div className="mr-2 mt-1 text-emerald-500">✓</div>
                  <span>Upload vehicle and driver details</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 text-emerald-500">✓</div>
                  <span>Track your vehicles in real-time</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 text-emerald-500">✓</div>
                  <span>Manage material transportation</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 text-emerald-500">✓</div>
                  <span>Get matched with clients automatically</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Link href="/register?role=transporter" className="w-full">
                <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
                  Register as Transporter
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card className="bg-slate-800 border-slate-700 text-white hover:bg-slate-700 transition-colors">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center mb-4">
                <Users className="w-6 h-6" />
              </div>
              <CardTitle className="text-2xl">For Clients</CardTitle>
              <CardDescription className="text-slate-300">
                Submit your transportation needs and get matched with suitable transporters.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <div className="mr-2 mt-1 text-blue-500">✓</div>
                  <span>Upload demand details easily</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 text-blue-500">✓</div>
                  <span>Specify material requirements</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 text-blue-500">✓</div>
                  <span>Set your budget and timeline</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 text-blue-500">✓</div>
                  <span>Get matched with transporters automatically</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Link href="/register?role=client" className="w-full">
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Register as Client
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>

        <div className="mt-16 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="bg-slate-800 p-6 rounded-lg">
              <div className="w-12 h-12 rounded-full bg-slate-700 flex items-center justify-center mx-auto mb-4 text-white font-bold">
                1
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Register & Create Profile</h3>
              <p className="text-slate-300">
                Sign up as a transporter or client and complete your profile with all necessary details.
              </p>
            </div>
            <div className="bg-slate-800 p-6 rounded-lg">
              <div className="w-12 h-12 rounded-full bg-slate-700 flex items-center justify-center mx-auto mb-4 text-white font-bold">
                2
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Submit Requirements</h3>
              <p className="text-slate-300">Transporters add vehicle details, clients submit transportation needs.</p>
            </div>
            <div className="bg-slate-800 p-6 rounded-lg">
              <div className="w-12 h-12 rounded-full bg-slate-700 flex items-center justify-center mx-auto mb-4 text-white font-bold">
                3
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Get Matched & Deliver</h3>
              <p className="text-slate-300">
                Our system matches transporters with clients based on compatibility and requirements.
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-slate-900 py-8 border-t border-slate-800">
        <div className="container mx-auto px-4 text-center text-slate-400">
          <p>© 2024 LogiMatch. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
