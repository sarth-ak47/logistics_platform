"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { createClient } from "@supabase/supabase-js"
import bcrypt from "bcryptjs"
import { getSupabaseServer } from "./supabase"

// Create a Supabase client for server-side operations
const createServerClient = () => {
  const cookieStore = cookies()
  return createClient(
    process.env.SUPABASE_URL || (process.env.NEXT_PUBLIC_SUPABASE_URL as string),
    process.env.SUPABASE_ANON_KEY || (process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string),
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value
        },
        set(name: string, value: string, options: any) {
          cookieStore.set({ name, value, ...options })
        },
        remove(name: string, options: any) {
          cookieStore.set({ name, value: "", ...options })
        },
      },
    },
  )
}

interface LoginData {
  email: string
  password: string
  role: "transporter" | "client"
}

interface RegisterData {
  name: string
  email: string
  password: string
  role: "transporter" | "client"
}

export async function loginUser(data: LoginData) {
  try {
    const supabase = getSupabaseServer()

    // Check if user exists and get their password hash
    const { data: user, error: userError } = await supabase
      .from("logistics_users")
      .select("id, email, password_hash, role, full_name")
      .eq("email", data.email)
      .eq("role", data.role)
      .single()

    if (userError || !user) {
      return { success: false, error: "Invalid email or password" }
    }

    // Verify password
    const passwordMatch = await bcrypt.compare(data.password, user.password_hash)
    if (!passwordMatch) {
      return { success: false, error: "Invalid email or password" }
    }

    // Sign in with Supabase Auth
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: data.email,
      password: data.password,
    })

    if (signInError) {
      return { success: false, error: signInError.message }
    }

    return {
      success: true,
      user: {
        id: user.id,
        name: user.full_name,
        email: user.email,
        role: user.role,
      },
    }
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function registerUser(data: RegisterData) {
  try {
    const supabase = getSupabaseServer()

    // Check if user already exists
    const { data: existingUser } = await supabase.from("logistics_users").select("id").eq("email", data.email).single()

    if (existingUser) {
      return { success: false, error: "Email already in use" }
    }

    // Hash password
    const passwordHash = await bcrypt.hash(data.password, 10)

    // Create user in Supabase Auth
    const { data: authUser, error: authError } = await supabase.auth.signUp({
      email: data.email,
      password: data.password,
    })

    if (authError) {
      return { success: false, error: authError.message }
    }

    // Create user in our custom table
    const { data: newUser, error: dbError } = await supabase
      .from("logistics_users")
      .insert({
        email: data.email,
        password_hash: passwordHash,
        full_name: data.name,
        role: data.role,
        is_verified: false,
      })
      .select()
      .single()

    if (dbError) {
      // Rollback auth user if db insert fails
      await supabase.auth.admin.deleteUser(authUser.user?.id as string)
      return { success: false, error: dbError.message }
    }

    return {
      success: true,
      user: {
        id: authUser.user?.id,
        name: data.name,
        email: data.email,
        role: data.role,
      },
    }
  } catch (error) {
    console.error("Registration error:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function logoutUser() {
  const supabase = createServerClient()
  await supabase.auth.signOut()
  redirect("/login")
}

export async function getCurrentUser() {
  const supabase = createServerClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session?.user) {
    return null
  }

  const { data } = await supabase
    .from("logistics_users")
    .select("id, email, full_name, role")
    .eq("email", session.user.email)
    .single()

  return data
}
