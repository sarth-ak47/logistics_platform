import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })

  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Check if the user is authenticated
  if (!session) {
    const url = new URL("/login", req.url)
    return NextResponse.redirect(url)
  }

  // Get user role from our custom table
  const { data: userData } = await supabase
    .from("logistics_users")
    .select("role")
    .eq("email", session.user.email)
    .single()

  // Check if the user is accessing the correct dashboard based on their role
  const path = req.nextUrl.pathname

  if (path.startsWith("/dashboard/transporter") && userData?.role !== "transporter") {
    const url = new URL("/dashboard/client", req.url)
    return NextResponse.redirect(url)
  }

  if (path.startsWith("/dashboard/client") && userData?.role !== "client") {
    const url = new URL("/dashboard/transporter", req.url)
    return NextResponse.redirect(url)
  }

  return res
}

export const config = {
  matcher: ["/dashboard/:path*"],
}
